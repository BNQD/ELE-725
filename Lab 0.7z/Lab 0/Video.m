VideoReader() v = VideoReader('keypad.avi');

s = struct('cdata', zeros(500, 500, 3, 'uint8', 'colormap', []);